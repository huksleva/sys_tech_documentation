## Операционное руководство

### 1. Архитектура контура
- `Wiki.js` работает в контейнере `node:20-bullseye`, файловая система примонтирована из `dist/wiki-js`.
- База — SQLite файл `data/wiki/wiki.sqlite`, доступный из контейнера как `./data/wiki.sqlite`.
- HTTP порт проброшен из контейнера `3000` на `WIKI_HTTP_PORT` (по умолчанию `3080`).
- Конфигурация (`config/config.yml`) и логи (`logs/`) лежат на хосте, что упрощает перенос и аудит.

### 2. Жизненный цикл сервисов
- **Запуск**: `./scripts/start.sh`
- **Остановка**: `./scripts/stop.sh`
- **Перезапуск**: `./scripts/stop.sh && ./scripts/start.sh` или `docker compose restart <service>`
- **Проверка состояния**: `./scripts/status.sh` (упрощённая) или `docker compose ps`

### 3. Резервное копирование / восстановление
- **SQLite snapshot**: `./scripts/backup.sh` вызывает `sqlite3 .backup` и создаёт `backups/wikijs-<timestamp>.sqlite`.
- **Ротация**: скрипт удаляет архивы старше `WIKI_BACKUP_RETENTION_DAYS` (стандарт — 7 дней). Требуется локальный CLI `sqlite3`.
- **Восстановление**:
  1. Остановите контейнер (`./scripts/stop.sh`).
  2. Скопируйте нужный бэкап поверх рабочей базы: `cp backups/<dump>.sqlite data/wiki/wiki.sqlite`.
  3. Запустите контейнер: `./scripts/start.sh`.

### 4. Обновление версии
1. В `.env` задайте нужный `WIKI_VERSION` (например, `v2.5.309`).
2. Запустите `./scripts/update.sh` — скрипт скачает архив, распакует и пересоздаст контейнеры.
3. После обновления проверьте `/setup` на наличие миграций.

### 5. Управление пользователями и доступом
- Создайте 4 учётные записи разработчиков через `Administration → Users`.
- Группа `Maintainers` подходит для R&D команды: полный доступ к пространствам и настройкам контента.
- Для гостевого чтения включите модуль `Public` и ограничьте его только на выбранные пространства.
- Для MFA активируйте встроенный TOTP: `Administration → Authentication → Local`.

### 6. TLS / Reverse Proxy
- Директория `config/certs/` содержит заглушки. Для prod-режима:
  1. Поместите `wiki-js.crt` и `wiki-js.key`.
  2. В `config/config.yml` установите `ssl.enabled: true`.
  3. Пробросьте порт `3443` в `compose.yml` (добавьте `- "3443:3443"`).
- Альтернатива — внешний reverse proxy (NGINX/Traefik) с Let’s Encrypt.

### 7. Логи и мониторинг
- Приложение пишет в `logs/` на хосте; контейнерные события смотрите через `docker logs $(docker compose ps -q wikijs)`.
- При необходимости отправляйте логи во внешнюю систему (`tail -f logs/*.log | vector ...`).
- Healthcheck встроен: `tools/docker-healthcheck.js`. При провале контейнер будет перезапущен Docker'ом.

### 8. Контроль изменений
- Любые правки `config/config.yml` фиксируйте в SCM (или храните патч в `/docs/change-log.md`), чтобы при переносе легко воспроизвести окружение.
- После модификаций выполняйте `./scripts/stop.sh && ./scripts/start.sh`, чтобы подхватить конфиг.
