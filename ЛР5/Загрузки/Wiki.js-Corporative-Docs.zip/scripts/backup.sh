#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${ROOT_DIR}/.env"
DB_FILE="${ROOT_DIR}/data/wiki/wiki.sqlite"

if [[ ! -f "${ENV_FILE}" ]]; then
  echo "[backup] .env is missing." >&2
  exit 1
fi

# shellcheck disable=SC1090
source "${ENV_FILE}"

: "${WIKI_BACKUP_RETENTION_DAYS:=7}"

if ! command -v sqlite3 >/dev/null 2>&1; then
  echo "[backup] sqlite3 CLI is required but not found." >&2
  exit 1
fi

if [[ ! -f "${DB_FILE}" ]]; then
  echo "[backup] SQLite file not found at ${DB_FILE}. Is Wiki.js initialized?" >&2
  exit 1
fi

timestamp="$(date +'%Y%m%d-%H%M%S')"
backup_dir="${ROOT_DIR}/backups"
mkdir -p "${backup_dir}"
backup_file="${backup_dir}/wikijs-${timestamp}.sqlite"

echo "[backup] Running sqlite3 online backup…"
sqlite3 "${DB_FILE}" ".backup '${backup_file}'"

echo "[backup] Applying retention (${WIKI_BACKUP_RETENTION_DAYS} days)"
find "${backup_dir}" -type f -mtime +"${WIKI_BACKUP_RETENTION_DAYS}" -delete

echo "[backup] Done. Snapshot saved to ${backup_file}"
