#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${ROOT_DIR}/.env"

if [[ ! -f "${ENV_FILE}" ]]; then
  echo "[bootstrap] .env is missing. Copy .env.example first." >&2
  exit 1
fi

# shellcheck disable=SC1090
source "${ENV_FILE}"

: "${WIKI_VERSION:?WIKI_VERSION is not set in .env}"

ARCHIVE_PATH="${ROOT_DIR}/dist/wiki-js-${WIKI_VERSION}.tar.gz"
EXTRACT_DIR="${ROOT_DIR}/dist/wiki-js"

require_tool() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "[bootstrap] Missing required tool: $1" >&2
    exit 1
  fi
}

require_tool curl
require_tool tar

mkdir -p "${ROOT_DIR}/dist" "${ROOT_DIR}/data/wiki" \
  "${ROOT_DIR}/logs" "${ROOT_DIR}/backups"

download_release() {
  if [[ -f "${ARCHIVE_PATH}" && "${1:-}" != "--force" ]]; then
    echo "[bootstrap] Archive already present (${ARCHIVE_PATH}). Use --force to re-download."
    return
  fi

  echo "[bootstrap] Fetching Wiki.js ${WIKI_VERSION}…"
  curl -L "https://github.com/requarks/wiki/releases/download/${WIKI_VERSION}/wiki-js.tar.gz" \
    -o "${ARCHIVE_PATH}"
}

extract_release() {
  echo "[bootstrap] Unpacking to ${EXTRACT_DIR}…"
  rm -rf "${EXTRACT_DIR}"
  mkdir -p "${EXTRACT_DIR}"
  tar -xzf "${ARCHIVE_PATH}" -C "${EXTRACT_DIR}"
}

download_release "$@"
extract_release

echo "[bootstrap] Done. You can now run scripts/start.sh"
