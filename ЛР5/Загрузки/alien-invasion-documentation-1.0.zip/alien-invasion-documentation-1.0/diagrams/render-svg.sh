#!/usr/bin/env bash
# Regenerates portable SVG diagrams from reference and student PlantUML sources.
set -euo pipefail

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
template_dir="$script_dir/../templates/diagrams"
cache_dir="${XDG_CACHE_HOME:-$HOME/.cache}/alien-invasion-plantuml"
plantuml_jar="${PLANTUML_JAR:-$cache_dir/plantuml.jar}"

if [ ! -f "$plantuml_jar" ]; then
  mkdir -p "$cache_dir"
  printf '%s\n' "Downloading PlantUML to $plantuml_jar"
  curl --fail --location --retry 2 \
    --output "$plantuml_jar" \
    https://github.com/plantuml/plantuml/releases/latest/download/plantuml.jar
fi

command -v java >/dev/null || {
  printf '%s\n' 'Java 17+ is required. Install a JRE, then run this script again.' >&2
  exit 1
}

render_directory() {
  source_dir=$1
  output_dir="$source_dir/svg"
  mkdir -p "$output_dir"

  found=false
  for source_file in "$source_dir"/*.puml; do
    [ -f "$source_file" ] || continue
    found=true
    (
      cd "$source_dir"
      java -jar "$plantuml_jar" -charset UTF-8 -tsvg -o svg "$(basename "$source_file")"
    )
  done
  "$found" || {
    printf '%s\n' "No PlantUML sources found in $source_dir" >&2
    exit 1
  }
  printf '%s\n' "Rendered SVG files to $output_dir"
}

render_directory "$script_dir"
render_directory "$template_dir"
